<!DOCTYPE html>
<html>
<head>
	<title>DASHBOARD</title>
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>
	<div class="col-sm-3 bg-info">
		<ul class="nav">
			<li class="nav-item"><a href="std_details.php">add student</a></li>
			<li class="nav-item"><a href="comp_details.php">add company</a></li>
			<li class="nav-item"><a href="eligible.php">view eligible student</a></li>
			
				
		</ul>
	</div>
		<div class="col-9">
			
		</div>
			

</body>
</html>