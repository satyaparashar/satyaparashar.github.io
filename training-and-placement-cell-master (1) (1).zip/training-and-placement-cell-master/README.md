# training-and-placement-cell
The Domain of our Project is to automate some of the work manually done in Training and placement cell of a college.The main motto is to successfully add students and company details and then sort out respective students who are eligible to attend an interview conducted by a company.
After successfully generating the list of students who are eligible to attend the interview process we have provided the option of printing those details with a single click of a button.
Further, Session  functionality has been provided so that unauthorised access can be restricted.
Also, a login page for admin has been provided.

Technologies used
FRONT-END DEVELOPMENT:

	HTML
	CSS
	JAVASCRIPT
BACK-END DEVELOPMENT:

	PHP
	MYSQL

